//Passing a parameter 'n' will return the first 'n' 
//elements of the array.

function first(array, number) {
    let max = number
    let arr =[];
if (number<0){
    max = 0;
    console.log(arr)
}
    if(number>array.length){
        max = array.length
    }
    for (let index = 0; index < max; index++) {
       arr.push(array[index])
        
    }
    
    return arr
    
}

//console.log(first([7, 9, 0, -2],1)); // [7]
console.log(first([7, 9, 0, -2],6)); // [7, 9, 0]
console.log(first([7, 9, 0, -2],-3)); // [7, 9, 0, -2]
