let student1Courses = ['Math', 'English', 'Programming'];
let student2Courses = ['Geography', 'Spanish', 'Programming'];

//Loop over the 2 arrays and if there are any common courses, if so console.log them

for (let array1 = 0; array1 < student1Courses.length; array1++) {
    for (let array2 = 0; array2 < student2Courses.length; array2++) {
        if (student1Courses[array1] === student2Courses[array2]) {
            console.log(student1Courses[array2])
        }
    }
}

