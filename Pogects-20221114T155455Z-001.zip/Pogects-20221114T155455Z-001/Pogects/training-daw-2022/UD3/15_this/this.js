const test1 = {
    prop: 42,
    func: function() {
        setTimeout(function() {
            console.log(this.prop)
       }, 2000)
    },
  };

const test = {
    prop: 42,
    func: function() {
        setTimeout(() => {
            console.log(this.prop)
       }, 2000)
    },
  };

test1.func()
test.func()


