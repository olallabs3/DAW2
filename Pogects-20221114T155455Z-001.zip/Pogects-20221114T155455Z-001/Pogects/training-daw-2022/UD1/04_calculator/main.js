// Declarar 2 variables con número e imprimir por consola (mediante console.log()) el valor de:
// Suma
// Resta
// Multiplicación
// División


// define variables
let x, y;
x = 3;
y = 5;

// print sum, substract, multiply and divide
console.log(`La suma es ${x+y}`)
console.log(`La resta es ${x-y}`)
console.log(`La multiplicación es ${x*y}`)
console.log(`La división es ${x/y}`)