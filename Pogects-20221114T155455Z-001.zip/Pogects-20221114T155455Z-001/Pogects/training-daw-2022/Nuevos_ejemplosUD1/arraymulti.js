const orderBySum = (someArray) => {
    let sortedArray = someArray.sort( (a,b) => a.reduce( (pv,cv) => pv + cv ) - b.reduce( (pv,cv) => pv + cv ))

    return  sortedArray
   /* for (let index = 0; index < someArray.length; index++) {
        let element = someArray[index]
            //console.log(`${element}: ${sumar(element)}`)

            /*
            let sortedArray = array.sort( function(a,b) {
        let sumaA = a.reduce( (pv,cv) => pv + cv )
        let sumaB = b.reduce( (pv,cv) => pv + cv )

        return sumaA - sumaB
    })*/
          
            //let valor = element.reduce ((pv ,cv) => pv + cv )
            
        }

    

 /*   function sumar (someArray) {
        let acumulador = 0;
        for (let index = 0; index < someArray.length; index++) {
            const element = someArray[index];
            acumulador = acumulador + element 
        }
        return acumulador
    }*/

console.log(orderBySum([[1,3], [4,2], [2,1]]))
// [[2,1], [1,3], [4,2]]