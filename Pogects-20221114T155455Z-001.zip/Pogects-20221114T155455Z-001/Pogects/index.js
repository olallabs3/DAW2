'use strict'

/*function hello(){
    console.log("Hello world!!")
}

hello();
*/

//Creamos variable string
let variable = "5";
console.log(typeof variable)
//Al ejecutar nos  dira que tipo de variable es

//Podemos reasignar el tipo de variable
variable = 5;
console.log(typeof variable)

//Para evitar errores hacemos cadenas interpoladas
let number = 3
variable =  `Tengo ${number} años`
console.log(variable)