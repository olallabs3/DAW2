window.onload = function(e) {
    console.log('documento cargado')

}

function btnocmos(id,idenl) {
    let id1 = document.getElementById(id)
    let id2 = document.getElementById(idenl)

    if (id1.style.display != "none"){
        id1.style.display = "none"
        document.getElementById(id2).innerHTML = "Mostrar"
    }
    else {
        id1.style.display = "block"
        document.getElementById(id2).innerHTML = "Ocultar"
    }
}