// Declarar un array numérico (entero) y crear un método que imprima:
// La suma de todos los elementos
// El elemento más grande
// El elemento más pequeño
// La media de los elementos

function doCalculation(array) {
    console.log(array)

    var suma =0;
    for (let index = 0; index < array.length; index++) {
        //Sacar suma
        suma = suma + array[index]

        //Sacar numero mayor
        var mayor = 0;
        if (mayor < array[index]){
            mayor = array[index]
        }

        
        //Sacar numero menor
        var menor = array[0];
        if (menor > array[index]){
            menor = array[index]
        }

      

        //Sacar la media
        var media = (suma / array.length)
    }

    //Sacar por pantalla
    console.log(suma)
    console.log(mayor)
    console.log(menor)
    console.log(media)

    //Metodo para sacar el maximo
    console.log(`El número mayor es ${(Math.max(...array))}`)
      //Metodo para sacar el minimo
      console.log(`El número menor es ${(Math.min(...array))}`)
}



SdoCalculation([1,2,3,4])
//doCalculation([5,5,5,5])
//doCalculation([1,1,1,2,2,2,3,3,3,4,4,4,5,5,5])