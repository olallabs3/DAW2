const onlyUnique = (someArray) => {

}

console.log(onlyUnique(1,1,2,3,3,4,4,5)) // [2,5]