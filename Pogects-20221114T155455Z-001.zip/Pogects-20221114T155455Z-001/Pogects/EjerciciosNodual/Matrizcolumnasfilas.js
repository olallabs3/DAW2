let array1 = []
let array2 = []
let array3 = []
let compmayo1 = 0;
let compmayo3 = 0;
let compmayo2 = 0;
let compmeno1 = 10;
let compmeno2 = 10;
let compmeno3 = 10;

for (let index = 0; index < 3; index++) {
    let numero = Math.floor(Math.random()*9+1)
    array1.push(numero);
}

for (let index = 0; index < 3; index++) {
    let numero = Math.floor(Math.random()*9+1)
    array2.push(numero);
}

for (let index = 0; index < 3; index++) {
    let numero = Math.floor(Math.random()*9+1)
    array3.push(numero);
}

console.log(array1)
console.log(array2)
console.log(array3)


for (let index = 0; index < array1.length; index++) {
    if(array1[index]>compmayo1){
        compmayo1 = array1[index]
    }
}
for (let index = 0; index < array2.length; index++) {
    if(array2[index]>compmayo2){
        compmayo2 = array2[index]
    }

}
for (let index = 0; index < array3.length; index++) {
    if(array3[index]>compmayo3){
        compmayo3 = array3[index]
    }

}
var silla = false
if (compmayo1<compmayo2 && compmayo1<compmayo3){
    silla = true
    console.log(silla,compmayo1)
}

if (compmayo2<compmayo1 && compmayo2<compmayo3){
    silla = true
    console.log(silla,compmayo2)
}

if (compmayo3<compmayo1 && compmayo3<compmayo2){
    silla = true
    console.log(silla,compmayo3)
}

// console.log(compmayo1)

// console.log(compmayo2)

// console.log(compmayo3)

// console.log(compmeno1)
// console.log(compmeno3)
// console.log(compmeno2)