const assert = require('assert').strict;

function nextPairs(value) {
    let array = [];

    if (value%2==0){
        array[0]= value-2;
        array[1]= value+2;
        
    }
    else{
        array[0]= value-1;
        array[1]= value+1;
    }
    console.log(array);
    return array
    
}

assert.deepStrictEqual(nextPairs(3), [2,4])
assert.deepStrictEqual(nextPairs(4), [2,6])