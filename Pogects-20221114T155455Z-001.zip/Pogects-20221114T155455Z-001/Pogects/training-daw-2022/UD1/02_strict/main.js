//Usamos el modo strict para mejorar nuestro código de cara a los errores
'use strict'


let x = 10

console.log('el valor de X ' + x)