window.onload = function(e) {
    console.log('documento cargado')
    //Cambiar el título del segundo h2 (check)
    document.getElementsByTagName('h2')[1].innerText = 'Has sido Krisseado'

    //Seleccionar el elemento con id == username (check)
    console.log(document.getElementById('username'))

    //Cambiar el color de todos los .first que estén dentro de un artículo (check)
    let colores = document.querySelectorAll("article .first");
    
        for (let index = 0; index < colores.length; index++) {
            colores[index].style.color="purple" 
        }
    //console.log(document.querySelectorAll("article .first"))


    //Seleccionar todos lo elementos li con class == item (check)
    console.log(document.querySelectorAll("li.items"))

    //Seleccionar todos lo buttons dentro de class == buttons
    console.log(document.querySelectorAll(".buttons button"))
    //console.log(document.getElementsByClassName("buttons").getElementsByTagName("button").length)

    //Cambiar el código de fondo del primer párrafo (check)
    document.querySelector(".first").style.backgroundColor = "lightgrey";

    //Cambiar el color de frente (forecolor) de los elementos buttons dentro de class == buttons  (check)
   let btn = document.querySelectorAll(".buttons button")

        for (let index = 0; index < btn.length; index++) {
            btn[index].style.color = "red"
        }
}