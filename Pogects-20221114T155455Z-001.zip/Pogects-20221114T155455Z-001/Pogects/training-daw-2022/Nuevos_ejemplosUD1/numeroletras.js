const input = 'Every developer likes to mix kubernetes and javascript';


//Escribe primera letra y ultima de la palabra y entre medio el numero de caracteres que hay entre esas dos letras siempre que la palabra sea mayor de 3 caracteres
let array = input.split(' ');
let final = []
for (let index = 0; index < array.length; index++) {
    let acumulador = array[index]

    if (acumulador.length>3){
        let numero = acumulador.length-2
        let frase = `${acumulador[0]}${numero}${acumulador[acumulador.length-1]}`
        final.push(frase)
    }

    //Si no queremos sacar las palabras de menos de 3 letras, quitamos el else
    else if (acumulador.length<=3){
        final.push(acumulador)
    }

}
console.log (final.join(' '))