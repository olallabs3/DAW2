window.onload = function() {
    //console.log(document.main_form.elements)

    console.log(document.getElementById('pregunta_si').value)
    console.log(document.getElementById('pregunta_si').checked)

    document.getElementById('pregunta_si').onchange = changeValue
    document.getElementById('pregunta_no').onchange = changeValue

    //document.getElementById('condiciones').onchange = changeValue
    //document.getElementById('privacidad').onchange = changeValue

}

function changeValue(e) {
     console.log('changed ' + e.target.value)
}
function checkRadio() {
    let statusYes = document.getElementById("pregunta_si").checked;
    let comboOpciones = document.getElementById("opciones");
    console.log(statusYes);

    if (statusYes) {
        comboOpciones.disabled = false;
    } else {
        comboOpciones.disabled = true;
    }
}

function checkbox() {
    var check1 = document.getElementById('condiciones').checked;
    var check2 = document.getElementById('privacidad').checked;

    if (check1 && check2) {
        document.getElementById('submit').disabled = false;
    } else {
        document.getElementById('submit').disabled = true;
    }
}