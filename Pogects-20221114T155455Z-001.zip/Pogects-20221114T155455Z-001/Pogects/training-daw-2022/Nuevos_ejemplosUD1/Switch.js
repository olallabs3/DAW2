let x = "0";
switch (x) {
    case 0:
        text = "Off";  break;
    case 1:
        text = "On";  break;
    default:
        text="No value found";
}
console.log(text)