class Coche{
//    totalGasolina=0;
    constructor(marca, modelo, consumoPor100){
        this.marca = marca
        this.modelo = modelo
        this.consumoPor100 = consumoPor100
        this.totalGasolina= 0
    }

    repostar(litros){
        this.totalGasolina =   this.totalGasolina+litros;
        //return(totalGasolina)
        console.log(`Has repostado ${this.totalGasolina}L`)
        console.log(`------------------------------------`)
    }

    move(distancia){
        this.totalGasolina = this.totalGasolina-(distancia/this.consumoPor100)
        //return(totalGasolina)
        console.log(`Se descuentan ${Math.floor(this.totalGasolina)}L por haber conducido ${distancia} Km`)
        console.log(`------------------------------------`)
    }

    restante(){
        let distancia = this.totalGasolina*this.consumoPor100/100
        //return(distancia)
        console.log(`Distancia que puedes hacer: ${distancia} Km`)
        console.log(`------------------------------------`)
    }
}

//const assert = require("assert").

let coche = new Coche("Audi","A6",7)

coche.repostar(50)
coche.move(200)
coche.restante()