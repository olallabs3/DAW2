console.log("Caso uno")

let miArray = ['uno',2,[3]]
miArray.unshift('hola');
miArray.push('adios');
for (let i =0; i<miArray.length; i++){
    console.log(miArray[i]);
}
console.log("")
miArray.pop();
miArray.shift();
for (let i =0; i<miArray.length; i++){
    console.log(miArray[i]);
}
/*
console.log(" ")
console.log("Caso dos")

for (let  item of miArray) {
    console.log(item);
}
console.log(" ")
console.log("Caso tres")

//CON EL IN NOS DA EL INDICE DEL OBJETO DEL ARRAY
for (let item in miArray) {
 console.log(miArray[item]);
}

miArray.push('hola');*/