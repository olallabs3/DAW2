const assert = require('assert').strict;

//FORMA 1 DE HACERLO
/*
function toHoursMinutesSeconds(value) {
    value/=3600
    let horas = Math.trunc(value);
    let minutos = (value-horas)*60
    value = minutos

    minutos = Math.trunc(value)
    let segundos = Math.trunc((value-minutos)*60)
    console.log(`${horas}:${minutos}:${segundos}`)

}*/


//FORMA 2 DE HACERLO
function toHoursMinutesSeconds(value) {
    let horas = Math.floor(value / 3600)
   // let rest = value - (horas * 3600)
    let minutos = Math.floor((value - (horas * 3600)) / 60 )
    let segundos = (value - (horas * 3600)) - (minutos * 60 )
    return `${horas}:${minutos}:${segundos}`
}

assert.deepStrictEqual(toHoursMinutesSeconds(3600), "1:0:0")
assert.deepStrictEqual(toHoursMinutesSeconds(3720), "1:2:0")
assert.deepStrictEqual(toHoursMinutesSeconds(4805), "1:20:5")