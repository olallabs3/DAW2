//function shuffle (array){
  

    let array = [10,12,15,56,23,4]
      console.log(array)
    for (let index = 0; index < array.length; index++) {
        let random = Math.floor(Math.random()*array.length)
        console.log(array[random])
        let nuevoarray =[];
        nuevoarray.push(random)
        
    }
    console.log(nuevoarray)
   
    /*console.log(array[random])
    let nuevoarray = []
    nuevoarray.push(random)

    console.log(nuevoarray)*/
    //return result; 
//}
console.log(shuffle([10,12,15,56,23,4]))