class Rectangle {

    // add x1, y1
    constructor(x, y,x1,y2) {
        this.x = x;
        this.y = y;
        this.x1= x1
        this.y1= y1
    }

    print() {
        console.log(`[${this.x}, ${this.y}]`)
    }

    // area
    calcularArea(){
        //console.log(this.x[0])
        return (this.x[1]-this.x[0])*(this.y[1]-this.y[0])

    }
    // overlay
    // tenemos que comprobar la siguiente situación
    // .x----------x.....
    // .|..........|.....
    // .|......x---|----x
    // .x------|---x....|
    // ........x--------x
    // ...........
    // .x--A-------x.....
    // .|..........|.....
    // .|......x---|----x
    // .x------|---x....|
    // ........x--------x

    // Se superponen si alguna de sus coordenadas están dentro de los límites
    // del otro rectángulo
}

let r1 = new Rectangle([5,9],[2,4]);

//
//
//
//
//


let r2 = new Rectangle([3,4],[8,6]);

r1.print()
r2.print()
console.log("------------------------")
console.log(`Área : ${r1.calcularArea()}`)
// let area = r1.area();
//console.log(`area ${area}`)

// let isOverlay = r1.overlay(r2)
