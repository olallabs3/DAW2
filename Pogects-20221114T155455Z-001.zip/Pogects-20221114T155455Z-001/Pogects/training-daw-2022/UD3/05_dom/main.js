console.log(document.getElementsByTagName("div")) 

//LISTAR ELEMENTOS CON STYLE =='BUTTONS'    

console.log(document.querySelector(".buttons"))

//LISTAR UN DIV CON CLASS == 'BUTTONS'

console.log(document.getElementsByClassName("buttons"))

//LISTAR TODOS LOS DIVS CON CLASS === 'BUTTONS'

console.log(document.querySelectorAll("div.buttons"))