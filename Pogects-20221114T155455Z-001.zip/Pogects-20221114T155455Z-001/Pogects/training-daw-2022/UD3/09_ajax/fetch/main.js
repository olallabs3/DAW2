window.onload = function () {
    console.log('document loaded');
    fetch('http://dummy.restapiexample.com/api/v1/employees')
        .then(response => response.json())
        .then(response => {
            console.log(response.data)
            let empleados = response.data

            for (let index = 0; index < empleados.length; index++) {
                onClick(empleados[index])
             }
        })
       
}

function onClick(empleados) {
    let tbody = document.getElementsByTagName('tbody')[0]

    let tr = document.createElement('tr')
    let td = document.createElement('td')
    let a = document.createElement('a')
    tr.appendChild(td)

    td.innerText = empleados.id
    tr.appendChild(td)

    td = document.createElement('td')
    td.innerText = empleados.employee_name
    tr.appendChild(td)

    td = document.createElement('td')
    td.innerText = empleados.employee_salary
    tr.appendChild(td)

    td = document.createElement('td')
    a = document.createElement('a')
    a.innerText = empleados.employee_age
    td.appendChild(a)
    tr.appendChild(td)

    tbody.appendChild(tr)
    console.log('added')
}

