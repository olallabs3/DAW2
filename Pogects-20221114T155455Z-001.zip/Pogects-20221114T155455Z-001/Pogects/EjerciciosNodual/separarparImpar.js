const splitByOddAndEven = (someArray) => {
    let arrayPar = []
    let arrayImpar = []

    for (let index = 0; index < someArray.length; index++) {
        if (someArray[index]%2==0){
                arrayPar.push(someArray[index])
        }
        if (someArray[index]%2!=0){
             arrayImpar.push(someArray[index])
        }
    }
        //return [arrayPar,arrayImpar]
        return [someArray.filter(v => v %2 ===0),someArray.filter (v => v %2 !=0)]
}



console.log(splitByOddAndEven([2, 3, 7, 6, 2, 4, 9]))
    // [[2, 4, 6], [3, 7, 9]]