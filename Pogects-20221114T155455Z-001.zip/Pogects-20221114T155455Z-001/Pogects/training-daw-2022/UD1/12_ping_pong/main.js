function pingPong() {

    for (let index = 0; index < 100; index++) {
        console.log(index,index%10=== 0 ? 'Pong': index % 5 === 0 ? 'Ping':'')
    }
    }
/*
    for (let index = 1; index < 100; index++) {

        if (index%5==0 && index%10!=0){
                console.log(`${index} PING`)
        }
        if (index%10==0){
            console.log(`${index} PONG`)
    }
    else {
        console.log(index)
    }
    }

}
*/


pingPong()
