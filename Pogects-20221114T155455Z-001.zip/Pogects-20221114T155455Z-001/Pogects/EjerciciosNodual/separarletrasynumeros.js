const sortTheArray = (someArray) => {
    //Otra manera de hacerlo
    //return someArray.sort();

    let numeros = []
    let letras = []
    for (let index = 0; index < someArray.length; index++) {
        let comprobar;
        comprobar = typeof someArray[index]
       if (comprobar == "number"){
           numeros.push( someArray[index])
       }
       else {
           letras.push(someArray[index])
       }
       
        }
        return [numeros+','+letras]
    }
    
//console.log(someArray[index])
console.log(JSON.stringify(sortTheArray(["b", 6, "a", "q", 7, 2])) )
// [2, 6, 7, "a", "b", "q"]