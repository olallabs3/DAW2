let autoin = 1;

function onClick() {
    let tbody = document.getElementsByTagName('tbody')[0]

    let tr = document.createElement('tr')
    let td = document.createElement('td')
    let a = document.createElement('a')
    //td.innerText = 
    td.innerText = autoin++
    tr.appendChild(td)

    td = document.createElement('td')
    td.innerText = 'Example'
    tr.appendChild(td)

    td = document.createElement('td')
    td.innerText = 'Surname'
    tr.appendChild(td)

    td = document.createElement('td')
    a = document.createElement('a')
    a.innerText = 'enlace'
    //a.href = `https://localhost/edit/`+ (autoin-1)
    td.appendChild(a)
    tr.appendChild(td)

    tbody.appendChild(tr)
    console.log('add')
}