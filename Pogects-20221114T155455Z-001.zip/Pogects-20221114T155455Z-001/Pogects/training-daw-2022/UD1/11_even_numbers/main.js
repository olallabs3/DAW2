function evenNumbers() {
for (let index = 0; index < 100; index++) {
    if (index%2===0){
        console.log(index)
    }
    
}
}

evenNumbers();
// expected output 2,4,6,8,10......98